-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2023 at 03:46 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blood_donation`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin@admin');

-- --------------------------------------------------------

--
-- Table structure for table `user_reg`
--

CREATE TABLE `user_reg` (
  `id` int(6) NOT NULL,
  `fname` varchar(25) NOT NULL,
  `lname` varchar(25) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(30) NOT NULL,
  `bgrup` varchar(30) NOT NULL,
  `lddate` datetime(6) NOT NULL,
  `pnumber` int(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `address` varchar(250) NOT NULL,
  `city` varchar(250) NOT NULL,
  `zip` varchar(20) NOT NULL,
  `country` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_reg`
--

INSERT INTO `user_reg` (`id`, `fname`, `lname`, `dob`, `gender`, `bgrup`, `lddate`, `pnumber`, `email`, `address`, `city`, `zip`, `country`) VALUES
(29, 'Divya Sree', 'Unni', '1993-12-18', 'female', 'b+', '2021-09-21 22:08:00.000000', 2147483647, 'divyasree@gmail.com', 'Sree Nilayam\r\nKalari\r\nKollam', 'Kollam', '908765', 'India'),
(30, 'arya', 's', '1999-01-24', 'female', 'o+', '2022-01-05 09:10:00.000000', 2147483647, 'aryas20@gmail.com', 'arya bhavanam', 'Thiruvananthapuram', '680536', 'India'),
(31, 'Umadevi', 'Gomathi', '1978-12-02', 'female', 'b+', '2023-02-01 18:12:00.000000', 2147483647, 'umadevigomathi11@gmail.com', 'Puthenpura Vadakketharayil, vadakkumthala po', 'Kollam', '690536', 'India'),
(32, 'Reena', 'Babu', '1992-02-23', 'female', 'a+', '2022-06-06 10:25:00.000000', 2147483647, 'reenababu97@gmail.com', 'daiva sadhanam,manappally po karunagappally', 'karunagappally', '690538', 'India');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_reg`
--
ALTER TABLE `user_reg`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_reg`
--
ALTER TABLE `user_reg`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
